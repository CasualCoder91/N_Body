MICADO Pipeline package
=======================